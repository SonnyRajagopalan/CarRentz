package com.sonny.carrentz.controller;

import org.junit.jupiter.api.Test;

public class CustomerControllerTest {
    @Test
    void testAddCustomer() {

    }

    @Test
    void testGetCustomerByDriveString() {

    }

    @Test
    void testGetCustomerByPhoneNumber() {

    }

    @Test
    void testGetRoot() {

    }
}
