package com.sonny.carrentz.controller;

public class InventoryControllerTest {
}
