package com.sonny.carrentz.controller;

import org.junit.jupiter.api.Test;

public class RentalControllerTest {
    @Test
    void testCreateRental() {

    }

    @Test
    void testReturnRental() {

    }

    @Test
    void testCreateRental2() {
        
    }

    @Test
    void testGetRentalById() {
        
    }
}
